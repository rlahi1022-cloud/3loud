#include <iostream>
#include <cstring>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <cstdio>
#include <string>
#include <thread>
#include <mutex>
#include <cstdlib>
#include <vector>
#include <atomic> // 플래그 제어용
#include "json.hpp"

using json = nlohmann::json;

// 플래그: 게임 진행 중 여부
std::atomic<bool> game_running(false);

bool send_json(int sock, const json &j)
{
    std::string payload = j.dump();
    uint32_t len = payload.size();
    uint32_t net_len = htonl(len);
    if (send(sock, &net_len, sizeof(net_len), 0) <= 0)
        return false;
    if (send(sock, payload.c_str(), len, 0) <= 0)
        return false;
    return true;
}

bool recv_json(int sock, json &out)
{
    uint32_t net_len;
    if (recv(sock, &net_len, sizeof(net_len), 0) <= 0)
        return false;
    uint32_t len = ntohl(net_len);
    std::vector<char> buffer(len);
    size_t received = 0;
    while (received < len)
    {
        ssize_t r = recv(sock, buffer.data() + received, len - received, 0);
        if (r <= 0)
            return false;
        received += r;
    }
    try
    {
        out = json::parse(buffer.begin(), buffer.end());
    }
    catch (...)
    {
        return false;
    }
    return true;
}

void clearScreen() { system("clear"); }
void wait_enter()
{
    std::cout << "(엔터)";
    std::cin.ignore();
    std::cin.get();
}
void wait_simple()
{
    std::cout << "(엔터)";
    std::cin.get();
}

// 수신 스레드
void receive_thread(int sock)
{
    while (true)
    {
        json j;
        if (!recv_json(sock, j))
        {
            std::cout << "\n서버 연결 끊김.\n";
            exit(0);
        }

        std::string type = j["type"];

        if (type == "chat")
        {
            if (game_running)
                std::cout << "[" << j["from"] << "] " << j["msg"].get<std::string>() << std::endl;
        }
        else if (type == "sys")
        {
            if (game_running)
                std::cout << "\n📢 " << j["msg"].get<std::string>() << "\n"
                          << std::endl;
        }
        else if (type == "game_over")
        { // ★ [기능 3] 게임 종료 신호
            std::cout << "\n🏁 " << j["msg"].get<std::string>() << "\n";
            game_running = false; // 플래그를 끄면 메인 루프가 로비로 돌아감
            // 강제로 프롬프트 리프레시를 위해 엔터 입력 유도 메시지는 서버 msg에 포함됨
        }
    }
}

int main()
{
    int sock = socket(PF_INET, SOCK_STREAM, 0);
    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    inet_pton(AF_INET, "10.10.20.115", &addr.sin_addr);
    addr.sin_port = htons(9004);

    if (connect(sock, (struct sockaddr *)&addr, sizeof(addr)) == -1)
    {
        perror("Connect failed");
        return 1;
    }

    // 1. 로그인/회원가입 루프
    bool login_success = false;
    while (!login_success)
    {
        clearScreen();
        std::cout << "====== [ LOGIN ] ======\n";
        std::cout << "1.로그인\n2.회원가입\n선택: ";
        int c;
        if (!(std::cin >> c))
        {
            std::cin.clear();
            std::cin.ignore(100, '\n');
            continue;
        }
        std::cin.ignore();

        if (c == 1)
        {
            std::string id, pw;
            std::cout << "ID: ";
            std::cin >> id;
            std::cout << "PW: ";
            std::cin >> pw;
            json j;
            j["type"] = "login";
            j["id"] = id;
            j["pw"] = pw;
            send_json(sock, j);

            json res;
            recv_json(sock, res);
            std::cout << "📢 " << res["msg"].get<std::string>() << std::endl;
            if (res["ok"])
            {
                login_success = true;
                wait_enter();
            }
            else
                wait_enter();
        }
        else if (c == 2)
        {
            std::string id, pw, nk;
            std::cout << "ID: ";
            std::cin >> id;
            std::cout << "PW: ";
            std::cin >> pw;
            std::cout << "Nick: ";
            std::cin >> nk;
            json j;
            j["type"] = "signup";
            j["id"] = id;
            j["pw"] = pw;
            j["nick"] = nk;
            send_json(sock, j);

            json res;
            recv_json(sock, res);
            std::cout << "📢 " << res["msg"].get<std::string>() << std::endl;
            wait_simple();
        }
    }

    // 수신 스레드 시작 (로그인 이후부터는 계속 백그라운드에서 동작)
    std::thread t(receive_thread, sock);
    t.detach();

    // 2. 메인 세션 루프 (로비 <-> 게임 반복)
    while (true)
    {
        // [로비 화면]
        game_running = false; // 확실히 게임 중 아님 표시
        clearScreen();
        std::cout << "====== [ LOBBY ] ======" << std::endl;
        std::cout << "1. 게임 입장 (채팅방)" << std::endl;
        std::cout << "2. 종료" << std::endl;
        std::cout << "선택 >> ";

        int choice;
        if (!(std::cin >> choice))
        {
            std::cin.clear();
            std::cin.ignore(100, '\n');
            continue;
        }
        std::cin.ignore();

        if (choice == 2)
        {
            close(sock);
            return 0;
        }
        if (choice == 1)
        {
            // [게임 입장]
            json enter;
            enter["type"] = "enter_room";
            send_json(sock, enter);

            game_running = true; // 게임/채팅 모드 활성화
            clearScreen();
            std::cout << "=== 채팅방 입장 (6명 대기중...) ===" << std::endl;

            // 채팅 루프
            while (game_running)
            {
                std::string line;
                std::getline(std::cin, line);

                // 게임이 끝났는데 엔터를 쳐서 getline이 넘어온 경우 루프 탈출
                if (!game_running)
                    break;
                if (line.empty())
                    continue;

                json j;
                if (line.find("/투표 ") == 0)
                {
                    j["type"] = "vote";
                    j["target"] = line.substr(8);
                }
                else if (line.find("/킬 ") == 0)
                {
                    j["type"] = "kill";
                    j["target"] = line.substr(8);
                } // 한글3바이트+공백1 = 4? 아니면 8? UTF-8 주의. "/킬 " -> 1+3+1=5?
                // 터미널 환경에 따라 다르나 보통 한글 3바이트. "/킬 " = 1 + 3 + 1 = 5.
                // 안전하게 공백 위치 찾기
                else if (line.find("/킬 ") == 0)
                {
                    j["type"] = "kill";
                    j["target"] = line.substr(line.find(' ') + 1);
                }
                else if (line.find("/치료 ") == 0)
                {
                    j["type"] = "heal";
                    j["target"] = line.substr(line.find(' ') + 1);
                }
                else if (line.find("/조사 ") == 0)
                {
                    j["type"] = "police";
                    j["target"] = line.substr(line.find(' ') + 1);
                }
                else if (line.find("/투표 ") == 0)
                {
                    j["type"] = "vote";
                    j["target"] = line.substr(line.find(' ') + 1);
                }
                else
                {
                    j["type"] = "chat";
                    j["msg"] = line;
                }

                send_json(sock, j);
            }
            // while(game_running)을 빠져나오면 다시 로비(while(true) 상단)로 돌아감
        }
    }
}